// Section CSC160 - Computer Science I: C++
// File Name: 
// Student: Trevor Green
// Homework Number: 12
// Description: Use class inhertance to sort shipping containers
// Last Changed: 5/7/2019

#include<iostream>
#include<cstdlib>
#include<string>
#include<vector>

using namespace std;

class ShippingContainer
{
public:
	int getID();
	void setID(int _ID);
	virtual string getManifest();
	virtual void add(string description);
	virtual void setManifest(string _manifest);
	ShippingContainer();
protected:
	int containerID;
};

class ManualShippingContainer : public ShippingContainer {
public:
	ManualShippingContainer();
	virtual string getManifest();
	void setManifest(string _manifest);
protected:
	string Manifest;
};

class RFIDShippingContainer : public ShippingContainer {
public:
	RFIDShippingContainer();
	virtual void add(string description);
	virtual string getManifest();
private:
	vector <string> itemList;
	vector <int> quantity;
	string description;
	
};

int main()
{
	ShippingContainer *array[6];

	array[0] = new ManualShippingContainer();
	array[0]->setManifest("ten bags of apples");
	
	array[1] = new ManualShippingContainer();
	array[1]->setManifest("four bags of peanuts");
	
	array[2] = new ManualShippingContainer();
	array[2]->setManifest("three bags of almonds");

	array[3] = new RFIDShippingContainer();
	array[3]->add(" bags of oranges");
	
	array[4] = new RFIDShippingContainer();
	array[4]->add(" bags of carrots");
	
	array[5] = new RFIDShippingContainer();
	array[5]->add(" bag of rice");

	
	for (int i = 0; i < 6; i++)
	{
		cout << array[i]->getManifest() << endl;
	}
	
	system("pause");
	return 0;
}

// Shipping Container Implementations
ShippingContainer::ShippingContainer() {
	containerID = 0;
}

int ShippingContainer::getID(){
	return containerID;
}
void ShippingContainer::setID(int _ID) {
	containerID = _ID;
}
string ShippingContainer::getManifest() {
	string manifest = "";
	return manifest;
}
void ShippingContainer::setManifest(string _manifest) {
}
void ShippingContainer::add(string description) {
}

// ManualShippingContainer Implementations

ManualShippingContainer::ManualShippingContainer() {
	Manifest = "";
}
string ManualShippingContainer::getManifest(){
	return Manifest;
}
void ManualShippingContainer::setManifest(string _manifest) {
	Manifest = _manifest;
}

// RFIDShippingContainer Implementations

RFIDShippingContainer::RFIDShippingContainer() {
	description = "";
}

void RFIDShippingContainer::add(string description) {
	for (int i = 0; i < itemList.size(); i++) {
		if (description == itemList[i]){
			quantity[i]++;
		return;
	}}
	itemList.push_back(description);
	quantity.push_back(1);
}
string RFIDShippingContainer::getManifest() {
	string RFIDManifest = "";
	for (int i = 0; i < itemList.size(); i++)
	{
		RFIDManifest += to_string(quantity[i]) + itemList[i];
	}
	return RFIDManifest;
}