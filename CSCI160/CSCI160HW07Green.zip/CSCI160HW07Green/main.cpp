#include <iostream>
#include <string>
#include <cctype>
using namespace std;
using namespace Authenticate;

int main()
{
	inputUserName();
	inputPassword();
	cout << "Your username is " << getusername << " and your password is " << getpassword << endl;
	

	return 0;
}