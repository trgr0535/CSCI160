#include <iostream>
#include <string>
#include <cctype>
using namespace std;

namespace {
	string getpassword;
	bool isValid()
	{
		if (getpassword.length >= 8)
		{
			for (int i = 0; i < getpassword.length(); i++)
			{
				if (!isalpha(getpassword[i]))
				{
					return false;
				}
				else
					return true;
			}

		}
	}
}
	namespace Authenticate
	{
		string getpassword;
		void inputPassword()
		{
			do
			{
				cout << "Enter your password (at least 8 characters and at least on nonletter)" << endl;
				cin >> getpassword;
			} while (!isValid());

		}
	}