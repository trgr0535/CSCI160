#include <iostream>
#include <string>
#include <cctype>
using namespace std;

namespace {
	string getusername;
	bool isValid()
	{
		if (getusername.length >= 8)
		{
			return true;
		}
		else
			return false;
	}
}
namespace Authenticate
{
	string getusername;
	void inputUserName()
	{
		do
		{
			cout << "Enter your password (at least 8 characters and at least on nonletter)" << endl;
			cin >> getusername;
		} while (!isValid());

	}
}

