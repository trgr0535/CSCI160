// Section CSC160 - Computer Science I: C++
// File Name: test.cpp
// Student: Trevor Green
// Homework Number: 7
// Description: Seperate assignment 11 into seperate files using a .h file
// Last Changed: 3/21/2019

#include <iostream>
#include "rational.h"
using namespace std;

int main()
{
	rational answer;
	rational numberOne, numberTwo;

	cin >> numberOne;
	cin >> numberTwo;

	answer = numberOne + numberTwo;
	cout << "Number 1 plus number 2 equals " << answer << endl;
	answer = numberOne - numberTwo;
	cout << "Number 1 minus number 2 equals " << answer << endl;
	answer = numberOne * numberTwo;
	cout << "Number 1 times number 2 equals " << answer << endl;
	answer = numberOne / numberTwo;
	cout << "Number 1 divided by number 2 equals " << answer << endl;

	if (numberOne > numberTwo)
		cout << "Number 1 is greater than 2 \n";
	if (numberOne == numberTwo)
		cout << "Number 1 is equal to number 2 \n";
	if (numberOne < numberTwo)
		cout << "Number 1 is less than number 2 \n";

	system("pause");
	return 0;
}