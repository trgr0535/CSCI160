// Section CSC160 - Computer Science I: C++
// File Name: lesson07-740-2.cpp
// Student: Trevor Green
// Homework Number: 7
// Description: Seperate assignment 11 into seperate files using a .h file
// Last Changed: 3/21/2019

#include <iostream>
#include "rational.h"
using namespace std;


rational::rational()
{
	numerator = 0;
	denominator = 1;
}
rational::rational(int _num, int _denom)
{
	numerator = _num;
	denominator = _denom;
}
rational::rational(int wholenumber)
{
	numerator = wholenumber;
	denominator = 1;
}
istream& operator >>(istream& input, rational& test)
{
	char trash;
	cout << "Enter a non-zero integer then / then another non-zero integer. \n";
	if (input.peek() == '(')
		input >> trash;
	input >> test.numerator >> trash >> test.denominator;
	if (input.peek() == ')')
		input >> trash;
	return input;
}
ostream& operator <<(ostream& output, rational& test)
{
	output << test.numerator << "/" << test.denominator;
	return output;
}
rational operator *(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = testOne.numerator * testTwo.numerator;
	denom = testOne.denominator * testTwo.denominator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
rational operator /(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = testOne.numerator * testTwo.denominator;
	denom = testOne.denominator * testTwo.numerator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
rational operator +(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = (testOne.numerator * testTwo.denominator) + (testOne.denominator * testTwo.numerator);
	denom = testOne.denominator * testTwo.denominator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
rational operator -(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = (testOne.numerator * testTwo.denominator) - (testOne.denominator * testTwo.numerator);
	denom = testOne.denominator * testTwo.denominator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
bool operator > (const rational& testOne, const rational& testTwo)
{
	bool answer;
	if ((double(testOne.numerator) / double(testOne.denominator)) > (double(testTwo.numerator) / double(testTwo.denominator)))
	{
		answer = true;
	}
	else
		answer = false;

	return answer;
}
bool operator ==  (const rational& testOne, const rational& testTwo)
{
	bool answer;
	if ((double(testOne.numerator) / double(testOne.denominator)) == (double(testTwo.numerator) / double(testTwo.denominator)))
	{
		answer = true;
	}
	else
		answer = false;

	return answer;
}
bool operator < (const rational& testOne, const rational& testTwo)
{
	bool answer;
	if ((double(testOne.numerator) / double(testOne.denominator)) < (double(testTwo.numerator) / double(testTwo.denominator)))
	{
		answer = true;
	}
	else
		answer = false;

	return answer;
}
// Found Online at www.geeksforgeeks.org (euclidean algorithm)
int gcd(int a, int b)
{
	if (a == 0)
		return b;
	return gcd(b % a, a);
}