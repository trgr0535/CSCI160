// Section CSC160 - Computer Science I: C++
// File Name: lesson07-740-2.h
// Student: Trevor Green
// Homework Number: 7
// Description: Seperate assignment 11 into seperate files using a .h file
// Last Changed: 3/21/2019


#include <iostream>
using namespace std;

class rational
{
public:
	rational();
	rational(int wholenumber);
	rational(int _num, int _denom);
	friend istream& operator >>(istream&, rational&);
	friend ostream& operator <<(ostream&, rational&);
	friend rational operator +(const rational&, const rational&);
	friend rational operator -(const rational&, const rational&);
	friend rational operator *(const rational&, const rational&);
	friend rational operator /(const rational&, const rational&);
	friend bool operator > (const rational& testOne, const rational& testTwo);
	friend bool operator ==  (const rational& testOne, const rational& testTwo);
	friend bool operator < (const rational& testOne, const rational& testTwo);
private:
	int numerator;
	int denominator;

};
int gcd(int a, int b);