// Section CSC160 - Computer Science I: C++
// File Name: lesson05-616-7
// Student: Trevor Green
// Homework Number: 5
// Description: Run functions on rational fractions using classes
// Last Changed: 3/7/2019

#include <iostream>
using namespace std;

class rational 
{
public:
	rational();
	rational(int _num, int _denom);
	rational add(const rational& right);
	rational sub(const rational& right);
	rational mult(const rational& right);
	rational div(const rational& right);

private:
	int numerator;
	int denominator;

};

int main()
{
	rational testOne(2,5), testTwo(3,7);
	cout << testOne.mult;


	system("pause");
	return 0;
}

rational::rational()
{
	numerator = 0;
	denominator = 1;
}
rational::rational(int _num, int _denom)
{
	_num = numerator;
	_denom = denominator;
}
rational rational::mult(const rational& right)
{
	rational answer;
	answer.numerator = numerator * right.numerator;
	answer.denominator;
	return answer;
}
rational rational::div(const rational& right)
{
	rational answer;
	answer.numerator = numerator * right.denominator;
	answer.denominator = denominator * right.numerator;
}
rational rational::add(const rational& right)
{
	rational answer;
	answer.numerator = (numerator * right.denominator) + (denominator * right.numerator);
	answer.denominator = (denominator * right.denominator);
}
rational rational::sub(const rational& right)
{
	rational answer;
	answer.numerator = (numerator * right.denominator) - (denominator * right.numerator);
	answer.denominator = (denominator * right.denominator);
}
