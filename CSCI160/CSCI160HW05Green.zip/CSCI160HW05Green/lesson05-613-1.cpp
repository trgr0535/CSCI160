// Section CSC160 - Computer Science I: C++
// File Name: lesson05-613-1
// Student: Trevor Green
// Homework Number: 5
// Description: Calculate interest on a loan in a class
// Last Changed: 3/7/2019

#include<iostream>
#include<fstream>
#include<string>
using namespace std;

class CDAaccount
{
public:
	CDAaccount();
	CDAaccount(double x, double y, double z);
	double getInterest();
	double getBalance();
	double getTerm();
	double getNewBalance();
	void input(istream&);

private:
	double balance;
	double interestRate;
	int term;
};
int main ()
{
	CDAaccount account(100, 10, 6);
	cout << "The balance is ";
	cout << account.getBalance() << endl;
	cout << "the interest rate is ";
	cout << account.getInterest() << endl;
	cout << "The term is ";
	cout << account.getTerm() << endl;
	cout << "The balance after maturity is ";
	cout << account.getNewBalance() << endl;
	

	CDAaccount accountTwo = CDAaccount();
	accountTwo.input(cin);
	cout << "The balance is ";
	cout << accountTwo.getBalance() << endl;
	cout << "the interest rate is ";
	cout << accountTwo.getInterest() << endl;
	cout << "The term is ";
	cout << accountTwo.getTerm() << endl;
	cout << "The balance after maturity is ";
	cout << accountTwo.getNewBalance() << endl;


	system("pause");
	return 0;
}
CDAaccount::CDAaccount()
{
}
CDAaccount::CDAaccount(double x, double y, double z)
{
	balance = x;
	interestRate = y;
	term = z;
}
double CDAaccount::getInterest()
{
	return interestRate;
}
double CDAaccount::getBalance()
{
	return balance;
}
double CDAaccount::getTerm()
{
	return term;
}
double CDAaccount::getNewBalance()
{
	double newBalance;
	double rateFraction, interest;
	rateFraction = interestRate / 100.0;
	interest = balance * rateFraction * (term/12.0);
	newBalance = balance + interest;
	return newBalance;
}
void CDAaccount::input(istream& inStream)
{
	cout << "Enter the new balance \n";
	inStream >> balance;
	cout << "Enter the new interestRate \n";
	inStream >> interestRate;
	cout << "Enter the new term \n";
	inStream >> term;
}





