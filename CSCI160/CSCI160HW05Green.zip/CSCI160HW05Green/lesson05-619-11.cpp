// Section CSC160 - Computer Science I: C++
// File Name: lesson05-619-11
// Student: Trevor Green
// Homework Number: 5
// Description: calculate average movie ratings
// Last Changed: 3/7/2019

#include <iostream>
#include <string>
using namespace std;

class Movie
{
public:
	Movie(string name, string rating);
	void setmovieName(string name) 
	{
		movieName = name;
	}
	string getmovieName()
	{
		return movieName;
	}
	void setmovieRating(string rating)
	{
		movieRating = rating;
	}
	string getmovieRating()
	{
		return movieRating;
	}
	void addRating(int rating)
	{
		if (rating == 1)
		{
			terrible++;
			numberOfRatings++;
		}
		else if (rating == 2)
		{
			bad++;
			numberOfRatings++;
		}
		else if (rating == 3)
		{
			OK++;
			numberOfRatings++;
		}
		else if (rating == 4)
		{
			good++;
			numberOfRatings++;
		}
		else if (rating == 5)
		{
			great++;
			numberOfRatings++;
		}
	}
		double averageRatings()
		{
			return (double((terrible * 1) + (bad * 2) + (OK * 3) + (good * 4) + (great * 5)) / double (numberOfRatings));
		}
private:
	string movieRating;
	string movieName;
	int numberOfRatings;
	int terrible;
	int bad;
	int OK;
	int good;
	int great;
};

int main()
{
	Movie movieOne(" The Adjustment Bureau ", " PG13 ");
	movieOne.addRating(5);
	movieOne.addRating(5);
	movieOne.addRating(5);
	movieOne.addRating(4);
	movieOne.addRating(4);
	cout << movieOne.getmovieName();
	cout << " has a rating of " << movieOne.getmovieRating();
	cout << " And an average rating of " << movieOne.averageRatings() << endl;

	Movie movieTwo = Movie(" I am number four ", " PG13 ");
	movieTwo.addRating(2);
	movieTwo.addRating(2);
	movieTwo.addRating(2);
	movieTwo.addRating(3);
	movieTwo.addRating(3);
	cout << movieTwo.getmovieName();
	cout << " has a rating of " << movieTwo.getmovieRating();
	cout << " And an average rating of " << movieTwo.averageRatings() << endl;

	system("pause");
	return 0;
}
Movie::Movie(string name, string rating)
{
	movieName = name;
	movieRating = rating;
	numberOfRatings = 0;
	terrible = 0;
	bad = 0;
	OK = 0;
	good = 0;
	great = 0;
}