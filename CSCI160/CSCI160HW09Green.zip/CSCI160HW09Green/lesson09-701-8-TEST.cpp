// Section CSC160 - Computer Science I: C++
// File Name: lesson09-701-8-TEST
// Student: Trevor Green
// Homework Number: 9
// Description: add and subtract numbers from a list using an array
// Last Changed: 4/17/2019
// Test file

#include<iostream>
#include<cstdlib>
#include"lesson09-701-8-HEADER.h"

using namespace std;

int main()
{
	list testList;
	int listSize;

	cout << " how many data items would you like to add? (maximum of 50) \n";
	cin >> listSize;
	
	for (int i = 0; i < listSize ; i++)
	{
		testList.addData();
	}
	
	cout << "\n\nThere are " << testList.getSize() << " values on the list";
	cout << "\nThe first value on the list is " << testList.getData(0);
	cout << "\nThe last value on the list is " << testList.getLast();
	testList.deleteLast();
	cout << "\nAfter deleting last value, there are " << testList.getSize() << " values left \n";
	listSize = listSize - 1;

	cout << "The new List is \n";
	for (int i = 0; i < listSize; i++)
	{
		cout << testList.getData(i) << endl;
	}
	
	if (testList.full())
		"the list is full \n";
	else
		cout << "the list is not full \n";
	
	
	system("pause");
	return 0;
}