// Section CSC160 - Computer Science I: C++
// File Name: lesson09-443-4
// Student: Trevor Green
// Homework Number: 9
// Description: Compute average and standard deviation of a list of numbers
// Last Changed: 4/17/2019

#include<iostream>
#include<cmath>

using namespace std;

void fillarray(double a[], int& scoresUsed);
double average(double a[], int scoresUsed);
double sd(const double a[], int scoresUsed, double averageNum);

int main()
{
	int scoresUsed;
	double averageNum, standardDeviation, data[10];

	fillarray(data, scoresUsed);
	averageNum = average(data, scoresUsed);
	standardDeviation = sd(data, scoresUsed, averageNum);
	
	cout << "the average of these numbers is " << averageNum << endl;
	cout << "the standard deviation of these numbers is " << standardDeviation << endl;
	
	system("pause");
	return 0;
}
void fillarray(double a[], int& scoresUsed)
{
	cout << "Enter up to ten non-negative values, terminated by the value n-1" << endl;
	cout << "I will compute the standard deviation and the average \n";

	int next, number;
	number = 0;

	cin >> next;


	while ((next >= 0) && (number < 10))
	{
		a[number] = next;
		number++;
		cin >> next;
	}
	scoresUsed = number;
}
double average(double a[], int scoresUsed)
{
	double total = 0;
	int num;
	for (num = 0; num < scoresUsed; num++)
	{
		total = total + a[num];
	}
	return (total / num);
}
double sd(const double a[], int scoresUsed, double averageNum)
{
	int number = 0;
	double newData[10], newAverage, standardDev;

	while (number < scoresUsed)
	{
		newData[number] = (pow((a[number] - averageNum),2));
		number++;
	}
	newAverage = average(newData, scoresUsed);
	standardDev = sqrt(newAverage);
	return standardDev;
}