// Section CSC160 - Computer Science I: C++
// File Name: lesson09-701-8-HEADER
// Student: Trevor Green
// Homework Number: 9
// Description: add and subtract numbers from a list using an array
// Last Changed: 4/17/2019
// header file

#include<iostream>
#include<cstdlib>

using namespace std;

const int MAX_LIST_SIZE = 50;

class list
{
public:
	list();
	void deleteLast();
	double getLast();
	double getData(int number);
	bool full();
	void addData();
	int getSize();


private:
	double datalist[MAX_LIST_SIZE];
	int size;
};

