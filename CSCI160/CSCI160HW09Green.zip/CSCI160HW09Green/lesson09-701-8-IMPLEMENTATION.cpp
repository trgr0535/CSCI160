// Section CSC160 - Computer Science I: C++
// File Name: lesson09-701-8-IMPLEMENTATION
// Student: Trevor Green
// Homework Number: 9
// Description: add and subtract numbers from a list using an array
// Last Changed: 4/17/2019
// implementation

#include<iostream>
#include<cstdlib>
#include"lesson09-701-8-HEADER.h"


using namespace std;

list::list() : size(0) {}

void list::addData()
{
	double newdata;
	cout << "enter new data item \n";
	cin >> newdata;

	datalist[size] = newdata;
	
	size = size + 1;
}
void list::deleteLast()
{
	size = size - 1;
}
double list::getLast()
{
	return datalist[size -1];
}
double list::getData(int number)
{
	return datalist[number];
}
bool list::full()
{
	return (size == MAX_LIST_SIZE);
}
int list::getSize()
{
	return size;
}


