// Section CSC160 - Computer Science I: C++
// File Name: 
// Student: Trevor Green
// Homework Number: 4
// Description: Get advice from a file than override with new advice.
// Last Changed: 2/21/2019

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>
#include<string>

using namespace std;

int main()
{
	ifstream inStream;
	ofstream outStream;

	cout << "Here is your advice. \n";

	inStream.open("hw4pr02input.txt");
		if (inStream.fail())
		{
			cout << "input file opening failed. \n";
			exit(1);
		}
		char next;
		inStream.get(next);
		
		while (!inStream.eof())
		{
			cout << next;
			inStream.get(next);
		}
		
		inStream.close();

		cout << endl << "Now enter your advice. Indicate the end of your input by pressing enter twice. \n";
	
	
	outStream.open("hw4pr02input.txt");
		if (outStream.fail())
		{
		cout << "input file opening failed. \n";
		exit(1);
		}
		cin.get(next);
		while (next != '\n' || cin.peek() != '\n')
		{
			outStream.put(next);
			cin.get(next);
		}
		outStream.close();
		
	system("pause");
	return 0;
}