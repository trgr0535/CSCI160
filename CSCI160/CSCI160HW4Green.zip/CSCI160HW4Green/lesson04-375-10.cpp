// Section CSC160 - Computer Science I: C++
// File Name: lesson04-37-2
// Student: Trevor Green
// Homework Number: 4
// Description: Find the average of a file of numbers
// Last Changed: 2/21/2019

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>
#include<string>

using namespace std;

int main()
{
	ifstream inStream;

	inStream.open("babynames2012.txt");
	if (inStream.fail())
	{
		cout << "input file opening failed. \n";
		exit(1);
	}
	
	string inputname;
	int rank;
	string boyname;
	string girlname;


	cout << "Enter a name (capitalize first letter) \n";
	cin >> inputname;

	int rankgirl;
	int rankboy;

	rankgirl = 0;
	rankboy = 0;

	while (!inStream.eof())
	{
		inStream >> rank;
		inStream >> boyname;
		inStream >> girlname;


		if (boyname == inputname)
		{
			cout << inputname << " Ranks " << rank << " of most popular boy names. \n";
			rankboy = rank;
		}

		if (girlname == inputname)
		{
			cout << inputname << " Ranks " << rank << " of most popular girl names. \n";
			rankgirl = rank;
		}

	}
		
		if (rankboy < 1)
		{
			cout << inputname << " does not rank in the top 1000 for boys. \n";
		}
		if (rankgirl < 1)
		{
			cout << inputname << " does not rank in the top 1000 for girls. \n";
		}



	
	system("pause");
	return 0;
}