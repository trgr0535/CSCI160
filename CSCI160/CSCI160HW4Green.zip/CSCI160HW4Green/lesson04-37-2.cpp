// Section CSC160 - Computer Science I: C++
// File Name: lesson04-37-2
// Student: Trevor Green
// Homework Number: 4
// Description: Find the average of a file of numbers
// Last Changed: 2/21/2019

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>

using namespace std;

int main()
{
	ifstream inStream;
	ofstream outStream;
	inStream.open("hw4pr01input.txt");
	if (inStream.fail())
	{
		cout << "input file opening failed. \n";
		exit(1);
	}
	
	double sum, average, next;
	int count;
	count = 0;
	sum = 0;

	while (inStream >> next)
	{
		sum = sum + next;
		count++;
	}

	average = sum / count;

	cout << "The average of " << count << " numbers is " << average << endl;

	system("pause");
	return 0;
}