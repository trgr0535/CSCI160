// Section CSC160 - Computer Science I: C++
// File Name: lesson01-104-2
// Student: Trevor Green
// Homework Number: 1
// Description: Calculate the square root of a number
// Last Changed: 1/27/2019

#include<iostream>
using namespace std;

int main()
{
	double n, guess, r, guesstwo, difference;

	cout << "This program calculates the square root of a number. \n";
	cout << "Enter any number. \n";
	cin >> n;
	guess = n / 2;
	guesstwo = guess;
	difference = guess;

	while (guess * 0.01 < difference)
	{
		r = n / guess;
		guess = (guess + r) / 2;
		difference = guesstwo - guess;
		guesstwo = guess;
	}
	
	cout << "The sqaure root of " << n << " is " << guess;
	cout << endl;
	
	system("pause");
	
	return 0;
}