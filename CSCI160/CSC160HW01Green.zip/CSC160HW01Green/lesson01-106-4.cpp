// Section CSC160 - Computer Science I: C++
// File Name: lesson01-106-4
// Student: Trevor Green
// Homework Number: 1
// Description: Calculate face value of a loan
// Last Changed: 1/27/2019

#include<iostream>
using namespace std;
int main()
{
	char choice;
	do
	{
	double months, intrestrt, amountneed, facevalue, monthlyrt;
	
	cout << "This is a discount installment loan calculator. \n";
	cout << " \n";
	cout << "Enter the intrest rate in percent. \n";
	cin >> intrestrt;
	cout << "Enter the amount you need. \n";
	cin >> amountneed;
	cout << "Enter the duration of the loan in months. \n";
	cin >> months;

	facevalue = amountneed / (1 - (intrestrt / 100) * (months / 12));
	monthlyrt = facevalue / months;

	cout << "The face value of the loan must be " << facevalue << endl;
	cout << "The monthly payment is" << monthlyrt << endl;
	cout << " \n";
	cout << "Do you want to calculate again Y or N? \n";
	cin >> choice;
	} 
	while (choice == 'Y');
	
	system("pause");

	return 0;
}