// Section CSC160 - Computer Science I: C++
// File Name: lesson01-105-5
// Student: Trevor Green
// Homework Number: 1
// Description: Compute volume of a sphere
// Last Changed: 1/27/2019

#include<iostream>
using namespace std;
int main()
{
	double radius, vm;
	
	cout << "Enter radius of a sphere. " << endl; 
	cin >> radius;
	vm = (4.0 / 3.0) * radius * radius;
	cout << " The volume is " << vm << endl;
	
	system("pause");
	return 0;
}