// Section CSC160 - Computer Science I: C++
// File Name: lesson05-616-7
// Student: Trevor Green
// Homework Number: 6
// Description: Run functions on rational fractions using friend classes
// Last Changed: 3/14/2019

#include <iostream>
using namespace std;

class rational 
{
public:
	rational();
	rational(int wholenumber);
	rational(int _num, int _denom);
	friend istream& operator >>(istream&, rational&);
	friend ostream& operator <<(ostream&, rational&);
	friend rational operator +(const rational&, const rational&);
	friend rational operator -(const rational&, const rational&);
	friend rational operator *(const rational&, const rational&);
	friend rational operator /(const rational&, const rational&);
	friend bool operator > (const rational& testOne, const rational& testTwo);
	friend bool operator ==  (const rational& testOne, const rational& testTwo);
	friend bool operator < (const rational& testOne, const rational& testTwo);
private:
	int numerator;
	int denominator;

};
int gcd(int a, int b);

int main()
{
	rational answer;
	rational numberOne, numberTwo;

	cin >> numberOne;
	cin >> numberTwo;
	
	answer = numberOne + numberTwo;
	cout << "Number 1 plus number 2 equals " << answer << endl;
	answer = numberOne - numberTwo;
	cout << "Number 1 minus number 2 equals " << answer << endl;
	answer = numberOne * numberTwo;
	cout << "Number 1 times number 2 equals " << answer << endl;
	answer = numberOne / numberTwo;
	cout << "Number 1 divided by number 2 equals " << answer << endl;
	
	if (numberOne > numberTwo)
		cout << "Number 1 is greater than 2 \n";
	if (numberOne == numberTwo)
		cout << "Number 1 is equal to number 2 \n";
	if (numberOne < numberTwo)
		cout << "Number 1 is less than number 2 \n";

	system("pause");
	return 0;
}

rational::rational()
{
	numerator = 0;
	denominator = 1;
}
rational::rational(int _num, int _denom)
{
	numerator = _num;
	denominator = _denom;
}
rational::rational(int wholenumber)
{
	numerator = wholenumber;
	denominator = 1;
}
istream& operator >>(istream& input, rational& test)
{
	char trash;
	cout << "Enter a non-zero integer then / then another non-zero integer. \n";
	if (input.peek() == '(')
		input >> trash;
	input >> test.numerator >> trash >> test.denominator;
	if (input.peek() == ')')
		input >> trash;
	return input;
}
ostream& operator <<(ostream& output, rational& test)
{
	output << test.numerator << "/" << test.denominator;
	return output;
}
rational operator *(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = testOne.numerator * testTwo.numerator;
	denom = testOne.denominator * testTwo.denominator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
rational operator /(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = testOne.numerator * testTwo.denominator;
	denom = testOne.denominator * testTwo.numerator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
rational operator +(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = (testOne.numerator * testTwo.denominator) + (testOne.denominator * testTwo.numerator);
	denom = testOne.denominator * testTwo.denominator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
rational operator -(const rational& testOne, const rational& testTwo)
{
	int num, denom;
	rational answer;
	int greatestcd;
	num = (testOne.numerator * testTwo.denominator) - (testOne.denominator * testTwo.numerator);
	denom = testOne.denominator * testTwo.denominator;
	greatestcd = gcd(num, denom);
	num = num / greatestcd;
	denom = denom / greatestcd;
	answer = rational(num, denom);
	return answer;
}
bool operator > (const rational& testOne, const rational& testTwo)
{
	bool answer;
	if ((double(testOne.numerator) / double(testOne.denominator)) > (double(testTwo.numerator) / double(testTwo.denominator)))
	{
		answer = true;
	}
	else
		answer = false;
	
	return answer;
}
bool operator ==  (const rational& testOne, const rational& testTwo)
{
	bool answer;
	if ((double(testOne.numerator) / double(testOne.denominator)) == (double(testTwo.numerator) / double(testTwo.denominator)))
	{
		answer = true;
	}
	else
		answer = false;

	return answer;
}
bool operator < (const rational& testOne, const rational& testTwo)
{
	bool answer;
	if ((double(testOne.numerator) / double(testOne.denominator)) < (double(testTwo.numerator) / double(testTwo.denominator)))
	{
		answer = true;
	}
	else
		answer = false;

	return answer;
}
// Found Online at www.geeksforgeeks.org (euclidean algorithm)
int gcd(int a, int b)
{
	if (a == 0)
		return b;
	return gcd(b % a, a);
}
