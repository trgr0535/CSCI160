// Section CSC160 - Computer Science I: C++
// File Name: lesson2-172-1
// Student: Trevor Green
// Homework Number: 2
// Description: Rock Paper Scissors
// Last Changed: 2/7/2019

#include<iostream>
using namespace std;
int main()
{
	char choice;
	do
	{
	
	int playerone, playertwo, R, P, S;
	R = 1;
	P = 2;
	S = 3;

	cout << "Player one enter 1(rock) 2(paper) or 3(scissors) \n";
	cin >> playerone;
	cout << "Player two enter 1(rock) 2(paper) or 3(scissors) \n";
	cin >> playertwo;

	if (playerone == R && playertwo == S)
		cout << "Player one wins";
	else if (playerone == R && playertwo == P)
		cout << "Player two wins";
	else if (playerone == R && playertwo == R)
		cout << "Tie";
	else if (playerone == P && playertwo == R)
		cout << "Player two wins";
	else if (playerone == P && playertwo == S)
		cout << "Player two wins";
	else if (playerone == P && playertwo == P)
		cout << "Tie";
	else if (playerone == S && playertwo == P)
		cout << "Player one wins";
	else if (playerone == S && playertwo == R)
		cout << "Player two wins";
	else
		cout << "Tie";

	cout << " \n";

	cout << "Do you want to play again Y or N? \n";

	cin >> choice;
	
	}
	while (choice == 'Y' || choice == 'y');

	system("pause");
	return 0;
}