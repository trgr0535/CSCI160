// Section CSC160 - Computer Science I: C++
// File Name: lesson2-176-6
// Student: Trevor Green
// Homework Number: 2
// Description: calculate Fibonacci sequence
// Last Changed: 2/7/2019

#include<iostream>
using namespace std;
int main()
{
	char choice;
	do
	{
		int size, days, period, x, y, crud;
		cout << "Enter the initial size of the green crud population. \n";
		cin >> size;
		cout << "Enter the number of days. \n";
		cin >> days;

		period = days / 5;
		y = 0;
		x = 0;


		while (x <= period)
		{
			crud = y + size;
			y = size;
			size = crud;
			x++;

			cout << "The green crud population is" << crud << "after" << days << "days. \n";
		}
		cout << "Do you want to calculate again Y or N? \n";
		cin >> choice;
	} 
	while (choice == 'Y');


	system("pause");
	return 0;
}