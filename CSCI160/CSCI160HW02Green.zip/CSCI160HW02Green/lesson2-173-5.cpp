// File Name: lesson2-173-5
// Student: Trevor Green
// Homework Number: 2
// Description: Calculate prime numbers 1-100
// Last Changed: 2/7/2019

#include<iostream>
using namespace std;
int main()
{
	for (int n = 3; n <= 100; n++)
	{
		for (int N = 2; N <= 21; N++)
			if (n % N == 0) {
				break;
			}
			else {
				cout << n << "is a prime number. \n";
		
			}
	}


	system("pause");
	return 0;
}