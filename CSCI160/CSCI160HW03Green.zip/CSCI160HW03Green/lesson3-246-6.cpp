// File Name: lesson3-246-6
// Student: Trevor Green
// Homework Number: 3
// Description: Calculates compound interest on a loan
// Last Changed: 2/13/19

#include<iostream>
using namespace std;

double interestDue(double initialBalPar, double interestRtPar, int monthsPar);
// Calculates intrest due on a loan given the intrest rate, initial balance, and number of months.
int main()
{
	char choice;
	do
	{
		double initialBal, interestRt, months, totalInterest;

		cout << "Credit card interest. \n";
		cout << "Enter initial balance. \n";
		cin >> initialBal;
		cout << "Enter interest rate as a decimal fraction (1.5% = .015). \n";
		cin >> interestRt;
		cout << "Enter the number of months for which interest must be paid. \n";
		cin >> months;

		totalInterest = interestDue(initialBal, interestRt, months);

		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout.precision(2);
		
		cout << "Your total interest is $" << totalInterest << endl;

		cout << "Repeat Y or N? \n";

		cin >> choice;

	}
	while (choice == 'Y' || choice == 'y');
	
	system("pause");
	return 0;
}
	
double interestDue(double initialBalPar, double interestRtPar, int monthsPar)
{ 
	double interest, balance, totalDue;
	
	balance = initialBalPar;

	for (int I = monthsPar; I>0; I--)
	{

		interest = balance * interestRtPar;
		balance = interest + balance;
	
	}
	totalDue = balance - initialBalPar;
	return totalDue;

}