// File Name: lesson3-245-3
// Student: Trevor Green
// Homework Number: 3
// Description:  outputs the value of the stock
// Last Changed: 2/13/19

#include<iostream>
using namespace std;
double price(int dollarsPar, int numeratorPar, int denominatorPar);
//calculates intrest owed 

int main()
{
	int dollars, numerator, denominator, shares;
	double stockprice, value;

	cout << "Enter stock price and number of shares. \n";
	cout << "Enter price as integers. Dollars, Numerator, Denominator. \n";
	cin >> dollars;
	cin >> numerator;
	cin >> denominator;
	cout << "Enter the number of shares held. \n";
	cin >> shares;
	
	stockprice = price(dollars, numerator, denominator);

	value = shares * stockprice;

	cout << shares << " of stock with market price $" << dollars << " " << numerator << "/" << denominator << "\n";
	
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	
	cout << "has a price of " << value << endl;

	system("pause");
return 0;
}
double price(int dollarsPar, int numeratorPar, int denominatorPar)
{ 
	return dollarsPar + (static_cast<double>(numeratorPar) / denominatorPar);
}
