// File Name: lesson3-300-6
// Student: Trevor Green
// Homework Number: 3
// Description: Calculate wind chill
// Last Changed: 2/13/19

#include<iostream>
#include<cmath>
using namespace std;

void introduction();
// description of program
void getInput(double& windspeed, double& temp);
// cin wind speed and temperature in degrees celcius
double windchill(double windspeed, double temp);
// Output windchill

int main( )
{
	double windspeed, temp;

	introduction( );
	getInput(windspeed, temp);
		
	cout << "Wind chill factor is ";
	cout << windchill(windspeed, temp) << endl;
	
	system("pause");
	return 0;
}

void introduction( )
{
	cout << "This program calculates windchill. \n";
}
void getInput(double& windspeed, double& temp)
{
	cout << "Enter the temperature in degrees celcius ( <= 10 degrees ). \n";
	cin >> temp;
	if (temp > 10)
		cout << "Please enter a value ( <= 10 degrees )";
	else
	cout << "Enter the wind speed in meters/second. \n";
	cin >> windspeed;
}
double windchill(double windspeed, double temp)
{
	double windchill;
	windchill = 13.12 + 0.6215 * temp - 11.37 * pow(windspeed, 0.16) + 0.3965 * temp * pow(windspeed, 0.16);
	
	return windchill;
}



