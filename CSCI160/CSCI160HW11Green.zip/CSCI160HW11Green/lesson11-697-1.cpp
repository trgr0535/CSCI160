// Section CSC160 - Computer Science I: C++
// File Name: 
// Student: Trevor Green
// Homework Number: 
// Description: 
// Last Changed: 4/30/2019

#include<iostream>
using namespace std;

class VectorDouble
{
public:
	VectorDouble();
	VectorDouble(int size);
	VectorDouble(VectorDouble& source);
	~VectorDouble();
	int capacity();
	int size();
	double valueAt(int i);
	void changeValueAt(int i, double d);
	void push_back(double num);
	void reserve(int spot);
	void resize(int newSize);
	void operator= (VectorDouble& _classOne);
private:
	int maxCount;
	int count;
	double *ptr;

};

int main()
{
	VectorDouble copy;
	int sizeVector;
	cout << "enter the size of your vector \n";
	cin >> sizeVector;
	
	VectorDouble test, testTwo(sizeVector), testThree(copy);

	cout << "the size of vector 1 is " << test.size() << endl;
	cout << "the capacity of vector 1 is " << test.capacity() << endl;
	cout << "the size of vector 2 is " << testTwo.size() << endl;
	cout << "the capacity of vector 2 is " << testTwo.capacity() << endl;
	cout << "the size of vector 3 is " << testThree.size() << endl;
	cout << "the capacity of vector 3 is " << testThree.capacity() << endl;

	int index;
	cout << "Enter index to check value \n";
	cin >> index;
	cout << "The value at " << index << "is " << test.valueAt(index) << endl;
	
	int newIndex;
	double newValue;
	cout << "Enter index to change value \n";
	cin >> newIndex;
	cout << "Enter new value for " << newIndex << " Index \n";
	cin >> newValue;
	test.changeValueAt(newIndex, newValue);

	double add;
	cout << "enter a number to add to the vector \n";
	cin >> add;
	test.push_back(add);
	cout << "After pushing back the vector the new capacity is " << test.capacity() << endl;

	int reserve;
	cout << "Enter the number of spots to reserve \n";
	cin >> reserve;
	test.reserve(reserve);
	cout << "After reserving " << reserve << " spots. The capacity is now " << test.capacity() << endl;

	int newSize;
	cout << "enter the new size of the vector \n";
	cin >> newSize;
	test.resize(newSize);
	cout << "After resising the vector the new capacity is " << test.capacity() << endl;

system("pause");
return 0;
}

VectorDouble::VectorDouble()
{
	maxCount = 50;
	count = 0;
	ptr = new double[maxCount];
}
VectorDouble::VectorDouble(int size)
{
	maxCount = size;
	count = 0;
	ptr = new double[size];
}
VectorDouble::VectorDouble(VectorDouble& source)
{
	count = source.count;
	maxCount = source.maxCount;

	maxCount = 50;
	count = 0;

	ptr = new double[source.maxCount];
	for (int i = 0; i < count; i++)
	{
		ptr[i] = source.ptr[i];
	}
}
VectorDouble::~VectorDouble()
{
	delete[] ptr;
}
int VectorDouble::capacity()
{
	return maxCount;
}
int VectorDouble::size()
{
	return count;
}
double VectorDouble::valueAt(int i)
{
	if (i < count)
		return ptr[i];
	else
	{
		cout << "Index input is not defined \n";
	}
}
void VectorDouble::changeValueAt(int i, double d)
{
	ptr[i] = d;
}
void VectorDouble::push_back(double num)
{
	if (count < maxCount)
	{
		ptr[count] = num;
	}
	else
	{
		double *temp;
		temp = new double[(maxCount * 2)];
		for (int i = 0; i < count; i++)
		{
			temp[i] = ptr[i];
		}
		delete[] ptr;
		temp[count] = num;
		ptr = temp;
		maxCount = maxCount * 2;
		count = count + 1;
	}
}
void VectorDouble::reserve(int spot)
{
	double *temp;
	temp = new double[(maxCount + spot)];
	for (int i = 0; i < count; i++)
	{
		temp[i] = ptr[i];
	}
	delete[] ptr;
	ptr = temp;
	maxCount = maxCount + spot;
}
void VectorDouble::resize(int newSize)
{
	double *temp;
	temp = new double[newSize];
	for (int i = 0; i < newSize; i++)
	{
		temp[i] = ptr[i];
	}
	delete[] ptr;
	ptr = temp;
	maxCount = newSize;
	if (newSize < count)
	{
		count = newSize;
	}
}
void VectorDouble::operator= (VectorDouble& _classOne)
{
	maxCount = 50;
	count = 0;

	count = _classOne.count;
	maxCount = _classOne.maxCount;

	for (int i = 0; i < count; i++)
	{
		ptr[i] = _classOne.ptr[i];
	}
}
