// Section CSC160 - Computer Science I: C++
// File Name: 
// Student: Trevor Green
// Homework Number: 11
// Description: add and subtract numbers from a list using a dynamic array
// Last Changed: 5/2/2019

#include<iostream>
#include<cstdlib>

using namespace std;

class ListDynamic
{
public:
	ListDynamic();
	void deleteLast();
	double getLast();
	double getData(int number);
	void addData();
	int getSize();


private:
	int size;
	int maxSize;
	double *ptr;

};

int main()
{
	ListDynamic testList;
	double listCount;

	cout << "How many data items would you like to add? \n";
	cin >> listCount;
	
	for (int i = 0; i < listCount; i++)
	
	{
		testList.addData();
	}

	cout << "\n\nThere are " << testList.getSize() << " values on the list";
	cout << "\nThe first value on the list is " << testList.getData(0);
	cout << "\nThe last value on the list is " << testList.getLast();
	testList.deleteLast();
	cout << "\nAfter deleting last value, there are " << testList.getSize() << " values left \n";

	cout << "The new List is \n";
	for (int i = 0; i < testList.getSize(); i++)
	{
		cout << testList.getData(i) << endl;
	}

	system("pause");
	return 0;
}

ListDynamic::ListDynamic()
{
	maxSize = 50;
	ptr = new double[maxSize];
	size = 0;
}

void ListDynamic::addData()
{
	double newData;
	cout << " \n enter new data item \n";
	cin >> newData;


	if (size < maxSize)
	{
		ptr[size] = newData; 

	}
	else
	{
		double *temp;
		temp = new double[maxSize + 1];
		for (int i = 0; i < size; i++)
		{
			temp[i] = ptr[i];
		}
		delete[] ptr;
		temp[size] = newData;
		temp = ptr;
	}
	size++;
}
void ListDynamic::deleteLast()
{
	size = size - 1;
}
double ListDynamic::getLast()
{
	return ptr[size - 1];
}
double ListDynamic::getData(int number)
{
	return ptr[number];
}
int ListDynamic::getSize()
{
	return size;
}